window.onload = function(){
    var t1 = 0;
    var t2 = 0;
    var t3 = 0;
    var t4 = 0;
    var oSearch = document.getElementById('Search');
    var oSousuo = document.getElementById('sousuo');
    var oDashboard = document.getElementById('dashboard');
    var oDash = document.getElementById('dash');
    var oLeft1 = document.getElementById('left-1');
    var oComputer =document.getElementById('computer');
    var aAdd = document.getElementById('add');
    var aSpan = oLeft1.getElementsByTagName('span');
    var oLeft2 = document.getElementById('left-2');
    var oBook = document.getElementById('book');
    var oLeft3 = document.getElementById('left-3');
    var oCog = document.getElementById('cog');
    var oLeft4 = document.getElementById('left-4');
    var oTask = document.getElementById('tasks');
    var aSpan2 = oLeft4.getElementsByTagName('span');
    var aAdd2 = document.getElementById('add2');
    var oLeft5 =document.getElementById('left-5');
    var oTh = document.getElementById('th');
    var oLeft6 = document.getElementById('left-6')
    var oMail = document.getElementById('mail');
    var oLeft7 = document.getElementById('left-7')
    var oVote = document.getElementById('vote');
    var aSpan3 = oLeft7.getElementsByTagName('span');
    var aAdd3 = document.getElementById('add3');
    var oLeft8 = document.getElementById('left-8');
    var oShop = document.getElementById('shop');
    var oLeft9 = document.getElementById('left-9');
    var oMap = document.getElementById('map');
    var oLeft10 = document.getElementById('left-10')
    var oGlass = document.getElementById('glass');
    var aSpan4 = oLeft10.getElementsByTagName('span');
    var aAdd4 = document.getElementById('add4');
    var oLeft11 = document.getElementById('left-11');
    var oUser = document.getElementById('user');
    var oLeft12 = document.getElementById('left-12');
    var oLevel = document.getElementById('level');
    var oTd = document.getElementsByTagName('td');
    var sTask = document.getElementById('sTask');
    var sSign = document.getElementById('sSign');
    var sEmail = document.getElementById('sEmail');
    var sBell = document.getElementById('sBell');
    var oCo1 = document.getElementById('co1');
    var oCo2 = document.getElementById('co2');
    var oCo3 = document.getElementById('co3');
    function spanmode(a,b){
        for(var i=3;i<6;i++){
            a[i].style.display = b;
        }
    }
    function mode2(a,b){
        a.onclick = function(){
            oDash.style.background = '#2A3542';
            oDashboard.style.color = '#908D93';
            oDash.style.color = '#908D93';
            this.style.background = '#2A3542';
            a.onmouseover = function(){
                this.style.background = '#35404D';
                b.style.color = '#FF6C60';
            }
            a.onmouseout = function(){
                this.style.background = '#2A3542';
                b.style.color = '#908D93';
            }
        }
        a.onmouseover = function(){
            b.style.color = '#FF6C60';
        }
        a.onmouseout = function(){
            b.style.color = '#908D93';
        }
    }
    function mode3(a,b){
        a.onmouseover = function(){
            this.style.background = '#35404D';
            b.style.color = '#FF6C60';
            this.style.color = 'white';
        }
        a.onmouseout = function(){
            this.style.background = '#2A3542';
            b.style.color = '#908D93';
            this.style.color = '#908D93';
        }
    }
    function left(L,name,add,span,t){
        L.onmouseover = function(){
            name.style.color = '#FF6C60';
        }
        L.onmouseout = function(){
            name.style.color = '#908D93';
        }
        L.onclick = function(){
            if(t==0){
                add.innerHTML = '-';
                t=1;
                spanmode(span,'block');
                L.style.height = '160px';
                this.style.background = '#35404D';
                this.style.color = 'white';
                L.onmouseout = function(){
                    name.style.color = '#FF6C60';
                }
                oDash.style.background = '#2A3542';
                oDashboard.style.color = '#908D93';
                oDash.style.color = '#908D93';
            }else {
                add.innerHTML = '+';
                t=0;
                spanmode(span,'none');
                this.style.color = '#908D93';
                L.style.height = '40px';
                L.style.background = '#2A3542';
                L.onmouseover = function(){
                    name.style.color = '#FF6C60';
                    this.style.background = '#35404D';
                }
                L.onmouseout = function(){
                    name.style.color = '#908D93';
                    this.style.background = '#2A3542';
                }
            }
        }
    }
    function sSpan(td,s) {
        td.onmousemove = function(){
            s.style.color = '#4EB6AB';
        }
        td.onmouseout = function(){
            s.style.color = '#A0A0A0';
        }
    }
    oSearch.onmouseover = function(){
        clearInterval( oSousuo.timer );
        oSousuo.timer = setInterval(function (){
            oSousuo.style.display = 'inline-block';
        },600);
    }
    oSearch.onmouseout = function(){
        clearInterval( oSousuo.timer );
        oSousuo.timer = setInterval(function (){
            oSousuo.style.display = 'none';
        },50);
    }
    left(oLeft1,oComputer,aAdd,aSpan,t1,oLeft4);
    left(oLeft4,oTask,aAdd2,aSpan2,t2);
    left(oLeft7,oVote,aAdd3,aSpan3,t3);
    left(oLeft10,oGlass,aAdd4,aSpan4,t4);
    mode2(oLeft2,oBook);
    mode2(oLeft3,oCog);
    mode2(oLeft5,oTh);
    mode2(oLeft6,oMail);
    mode2(oLeft8,oShop);
    mode2(oLeft9,oMap);
    mode2(oLeft11,oUser);
    mode2(oLeft12,oLevel);
    mode3(oDash,oDashboard);
    sSpan(oTd[0],sTask);
    sSpan(oTd[1],sSign);
    sSpan(oTd[2],sEmail);
    sSpan(oTd[3],sBell);
    oCo1.onmousemove = function(){
        this.style.background = 'white';
    }
    oCo1.onmouseout = function(){
        this.style.background = '#E6E7EC';
    }
    oCo2.onmousemove = function(){
        this.style.background = 'white';
    }
    oCo2.onmouseout = function(){
        this.style.background = '#E6E7EC';
    }
    oCo3.onmousemove = function(){
        this.style.background = 'white';
    }
    oCo3.onmouseout = function(){
        this.style.background = '#E6E7EC';
    }
}